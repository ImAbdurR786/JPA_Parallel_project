/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.project.service;

import com.cg.project.bean.Customer;
import com.cg.project.dao.DAO;

/**
 *
 * @author Raja
 */
public class Service {
    DAO dao = new DAO();


    public void create(Customer c) {
        dao.create(c);
    }

    public void deposite(long accountdeposit, int deposite) {
        dao.deposite(accountdeposit,deposite);
    }

    public Customer show(Long showaccount) {
     return dao.show(showaccount);
   }


    public boolean contain(long accountdeposit) {
       boolean check = dao.checkAccount(accountdeposit);
       return check;
    }

    public int withdraw(long accountwithdraw, int withdraw) {
        int result = dao.withdraw(accountwithdraw,withdraw);
        return result;
}

    public int fundTransfer(Long from, Long to, int money) {
      Customer cFrom = dao.show(from);
		int fBalance = cFrom.getBalance();
		if(money<fBalance) {
			Customer cTo = dao.show(to);
			int totalMoney = cTo.getBalance() + money;
			 cTo.setBalance(totalMoney);
			// d.trans("Deposite"+money+"from account no."+from,to); 
			
			 int totalMony = fBalance - money;
			 cFrom.setBalance(totalMony);
			// d.trans("Transfer"+money+"to account no."+to,from); 
								
			return 1;
			}
		else 
			return -1;
    }
}



