/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.project.dao;

import com.cg.project.bean.Customer;

/**
 *
 * @author Raja
 */
public class DAO {

    public void create(Customer c) {
    
       EntityManagerFactory emf=Persistence.createEntityManagerFactory("abcd");
	EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(c);
        em.getTransaction().commit();
    }

    public Customer show(Long showaccount) {
         EntityManagerFactory emf=Persistence.createEntityManagerFactory("abcd");
	EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
      Customer cust = (Customer) em.find(Customer.class, new Long(showaccount));
      return cust;
    }

    public boolean checkAccount(long accountdeposit) {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("abcd");
	EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
      Customer cust = (Customer) em.find(Customer.class, new Long(showaccount));
     if(cust==null){
     return false;}
     else 
         return true;
    }

    public void deposite(long accountdeposit, int deposite) {
      EntityManagerFactory emf=Persistence.createEntityManagerFactory("abcd");
	EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        Customer cust = (Customer) em.find(Customer.class,new Long(accountdeposit));
        cust.setBalance(cust.getBalance() + deposite);
        
    }

    public int withdraw(long accountwithdraw, int withdraw) {
     EntityManagerFactory emf=Persistence.createEntityManagerFactory("abcd");
	EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        Customer cust = (Customer) em.find(Customer.class,new Long(accountwithdraw));
       
        cust.setWithdraw(withdraw);
        
		int balance = cust.getBalance() - cust.getWithdraw();
		if(balance>0) {cust.setBalance(balance);
                return 1;
                }else
			return -1;
    }
    
}




