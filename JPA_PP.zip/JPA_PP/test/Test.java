/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.cg.project.bean.Customer;
import com.cg.project.dao.UtilJava;
import javax.persistence.EntityManager;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class Test {
    	private EntityManager entityManager;

	public Test() {
		entityManager = UtilJava.getEntityManager();
	}

   
	@Test
	public void testShowBalance(long accountNo, String password)
	{
		entityManager.getTransaction().begin();
		Customer customer = entityManager.find(Customer.class, accountNo);
		
		int observed= customer.getBalance();
		int expected=1000;
		Assertions.assertEquals(expected, observed);
	}
    
}

