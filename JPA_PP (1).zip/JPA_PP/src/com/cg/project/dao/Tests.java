package com.cg.project.dao;
import com.cg.project.bean.Customer;

import javax.persistence.EntityManager;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class Tests {
    	private EntityManager entityManager;

    	
	public Tests() {
		entityManager = UtilJava.getEntityManager();
	}

   
	@Test
	public void testShowBalance()
	{
		entityManager.getTransaction().begin();
		Customer customer = entityManager.find(Customer.class, new Long(699831118));
		
		int observed= customer.getBalance();
		int expected=1000;
		Assertions.assertEquals(expected, observed);
	}
    
}

