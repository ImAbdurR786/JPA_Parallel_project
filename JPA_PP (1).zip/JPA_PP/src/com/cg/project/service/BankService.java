/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg.project.service;

import com.cg.project.bean.Customer;
import com.cg.project.bean.Transaction;
import com.cg.project.dao.BankDAO;
import com.cg.project.exception.NameException;
import com.cg.project.exception.NumberException;

import java.util.List;
import java.util.regex.Pattern;

public class BankService {
    BankDAO bankDao = new BankDAO();
    public void createAccount(Customer customer) {
                bankDao.beginTransaction();
                bankDao.createAccount(customer);
                bankDao.commitTransaction();
    }

    public boolean contain(Long accountNo) {
        return  bankDao.conatin(accountNo);
    }

    public boolean checkPin(int pin, Long accountNo) {
        return bankDao.checkPin(pin,accountNo);
    }

    public int showbalance(Long accountNo) {
     return bankDao.showbalance(accountNo);
    }

    public void depositeBalance(long accountNumber, int deposite,Transaction transaction) {
                bankDao.beginTransaction();
                Customer customer = bankDao.getCustomerByAccountNo(accountNumber);
                customer.setBalance(customer.getBalance()+deposite);
                transaction.setCustomer(customer);
                bankDao.depositeBalance(customer,transaction);
                bankDao.commitTransaction();
                
    }

    public int withdraw(long accountNu, int withdraw, Transaction transaction) {
            bankDao.beginTransaction();
            Customer customer = bankDao.getCustomerByAccountNo(accountNu);
            if(customer.getBalance()> withdraw){
               customer.setBalance(customer.getBalance()-withdraw);
               transaction.setCustomer(customer);
               bankDao.withdrawBalance(customer,transaction);
               bankDao.commitTransaction();
            return 1;
            }else{
            return -1;
            }
    }

    public int fundTransfer(Long fromAcc, Long toAcc, int money, Transaction transaction1, Transaction transaction2) {
    	bankDao.beginTransaction();
    	 Customer customer1 = bankDao.getCustomerByAccountNo(fromAcc);
        if(customer1.getBalance()>money){
            Customer customer2 = bankDao.getCustomerByAccountNo(toAcc);
           
            transaction1.setCustomer(customer1);
            transaction2.setCustomer(customer2);
            customer2.setBalance(customer2.getBalance()+money);
            customer1.setBalance(customer1.getBalance()-money);
            
            bankDao.fundTransfer(customer1,customer2);
            bankDao.fundTrans(transaction1, transaction2);
            bankDao.commitTransaction();
         return 1;
        }else{
        return -1;}
    }

    public List<Transaction> printTransaction(long transAccNo) {
     return bankDao.printTransaction(transAccNo); 
    }   

    public boolean isNameValid(String name) {
    if(name.length()>4){
     if(Pattern.matches("([A-Z])*([a-z])*", name)){
        return true;
          }else
            return false;
     }else {
    	try {
    		throw new NameException("Name is not Valid");
    	} catch(NameException e) {
    	       return false;	
    	}
    }}

    public boolean isNumberValid(String number) {
        if (number.matches("^[6-9][0-9]{9}$"))
            {
                return true;
            }
        else {
        	try {
           
        		throw new NumberException("Number is not valid");
        		}catch(NumberException e) {
            	return false;
            }
  }}
}