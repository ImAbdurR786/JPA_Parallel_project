package com.cg.project.exception;

public class NameException extends RuntimeException {
public NameException(String str) {
System.out.println(str);
}
}
